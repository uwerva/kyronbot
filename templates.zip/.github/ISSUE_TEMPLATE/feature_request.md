---
name: Feature request
about: Suggest an idea or improvement for the project
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## Is your feature request related to a problem?

Describe the problem or limitation you are experiencing.

## Describe the solution you'd like

Explain clearly what you would like to happen.

## Describe alternatives you've considered

Describe any alternative solutions or features you have considered.

## Use case

Explain how this feature would be useful and who would benefit from it.

## Additional context

Add screenshots, examples, references, or other context if relevant.

## Checklist

- [ ] I searched existing issues for similar requests.
- [ ] I have explained the use case.
